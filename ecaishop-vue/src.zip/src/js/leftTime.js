(function(y, g) {
	Date.prototype.format = function(a) {
		var d = {
			"M+": this.getMonth() + 1,
			"d+": this.getDate(),
			"h+": this.getHours(),
			"m+": this.getMinutes(),
			"s+": this.getSeconds(),
			"q+": Math.floor((this.getMonth() + 3) / 3),
			S: this.getMilliseconds()
		};
		/(y+)/.test(a) && (a = a.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length)));
		for (var c in d)(new RegExp("(" + c + ")")).test(a) && (a = a.replace(RegExp.$1, 1 == RegExp.$1.length ? d[c] : ("00" + d[c]).substr(("" + d[c]).length)));
		return a
	};
	g.leftTime = function(a, d, c) {
		function w(a) {
			return - 1 != a.indexOf("-") || -1 != a.indexOf("/") ? !0 : !1
		}
		function g(a) {
			return /^(20|21|22|23|[0-1]\d):[0-5]\d$/.test(y.trim(a)) ? !0 : !1
		}
		function r(a) {
			10 > a && c && (a = "0" + a);
			return a
		}
		function z() {
			if ("string" === typeof a || "number" === typeof a) {
				var b = (new Date).getTime(),
				c;
				"string" === typeof a || 12 <= a.toString().length ? (a = "string" === typeof a && 1 == w(a) ? a.replace(/-/g, "/") : a, c = (new Date(a)).getTime(), b = c - b) : (c = a - A.count, b = 1E3 * c, A.count++);
				0 < b ? (h = Math.floor(b / 1E3 / 60 / 60 / 24), k = Math.floor(b / 1E3 / 60 / 60 % 24), l = Math.floor(b / 1E3 / 60 % 60), m = Math.floor(b / 1E3 % 60), n = !0) : (window.clearInterval(e), m = l = k = h = 0, n = !1)
			} else "object" === typeof a && (b = (new Date).getTime() + (0 < t ? -1 * t: Math.abs(t)), c = 0, u < f ? (c = f, v = 1) : u >= f && u < p ? (c = p, v = 2) : u >= p && (v = 3), b = c - b, 0 < b ? (h = Math.floor(b / 1E3 / 60 / 60 / 24), k = Math.floor(b / 1E3 / 60 / 60 % 24), l = Math.floor(b / 1E3 / 60 % 60), m = Math.floor(b / 1E3 % 60), n = !0) : (window.clearInterval(e), m = l = k = h = 0, n = !1));
			b = {
				d: r(h),
				h: r(k),
				m: r(l),
				s: r(m)
			};
			b.status = n;
			b.step = v;
			if (d && "function" === typeof d) return d(b)
		}
		var e = this.timer;
		c || 0 == c || (c = !0);
		var A = {
			count: 0
		},
		h = 0,
		k = 0,
		l = 0,
		m = 0,
		v = 0,
		n = !1;
		if ("object" === typeof a) {
			a.init || 1 == a.init || (a.init = !1);
			var t = 0,
			x, q = 0;
			if (0 != a.setday || "0" != a.setday) q = 864E5 * parseInt(a.setday);
			a.nowdate && null != a.nowdate && void 0 != a.nowdate && "undefined" != a.nowdate ? (t = (new Date).getTime() - parseInt(a.nowdate), x = new Date(a.nowdate)) : (a.nowdate = (new Date).getTime(), x = new Date);
			var q = new Date(parseInt(a.nowdate) + q),
			f = 0,
			p = 0;
			0 == a.startdate || "0" == a.startdate || a.init || ("string" === typeof a.startdate ? w(a.startdate) ? f = (new Date(a.startdate.replace(/-/g, "/"))).getTime() : g(a.startdate) && (f = (new Date(q.format("yyyy/MM/dd") + " " + a.startdate)).getTime()) : "number" === typeof a.startdate && (f = a.startdate));
			if (0 != a.enddate || "0" != a.enddate)"string" === typeof a.enddate ? w(a.enddate) ? p = (new Date(a.enddate.replace(/-/g, "/"))).getTime() : g(a.enddate) && (p = (new Date(q.format("yyyy/MM/dd") + " " + a.enddate)).getTime()) : "number" === typeof a.enddate && (f = a.enddate);
			var u = x.getTime()
		}
		z();
		e = setInterval(z, 1E3);
		if ("undefined" != e || null != e || void 0 != e) return e
	};
	y.extend(g)
})(jQuery || zepto, {});