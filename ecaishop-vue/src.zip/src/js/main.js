/**
 * Created by Administrator on 2017/6/30.
 */
$('.go-top').click(function () {
    console.log(1)
    $(window).scrollTop(0)
})
$('.contact-store').click(function () {
    location.href = '帮助中心-在线客服.html'
})